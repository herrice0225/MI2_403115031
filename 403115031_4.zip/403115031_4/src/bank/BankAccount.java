package bank;

import java.util.ArrayList;

public class BankAccount {
	String state;
	int accountNumber;
	private double balance;
	private ArrayList<Double> TransactionList = new ArrayList<Double>();
	
	public BankAccount(){
		this(-1, -1);
	}
	
	public BankAccount(int anAccountNumber){
		this(anAccountNumber, 0);
	}	
	public BankAccount(int anAccountNumber, double initialBalance){
		this.state = "open";
		this.accountNumber = anAccountNumber;
		this.balance = initialBalance;
		this.TransactionList = new ArrayList<Double>();
	}
	double getbalance(int accountNumber){  //get the balance for the Bank class
		return this.balance;
	}
	
	public void deposit(double amount){
		if (!this.isOpen(this.state) || amount < 0){
			System.out.println("It is not valid.");
		}else{
			this.balance = this.balance + amount;
			addTransaction(amount);
		}		
	}
	public void withdraw(double amount){
		if (!this.isOpen(this.state) || amount < 0 || amount > this.balance){
			System.out.println("It is not valid.");
		}else{
			this.balance = this.balance - amount;
			addTransaction(0 - amount);
		}		
	}
	
	void suspend(){
		if (this.balance > 0){
			this.state = "suspended";
		}
	}
	void close(){
		if (this.state.equalsIgnoreCase("open") || this.state.equalsIgnoreCase("suspended")){
			this.state = "open";
		/*	withdraw(this.balance); */ //It will make the output count one more transaction.  
			this.state = "closed";
			}
		}
	void reOpen(){
		if (this.state.equalsIgnoreCase("closed") || this.state.equalsIgnoreCase("suspended")){
		this.state = "open";
		}
	}
	
	boolean isOpen(String state){
		if(this.state.equals("open")){
		return this.state.equalsIgnoreCase("open");
		}
		else return false; 
	}	
	boolean isSuspended(String state){
		if(this.state.equals("suspended")){
			return this.state.equalsIgnoreCase("Suspended");
		}
		else return false;
	}	
	boolean isClosed(String state){
		if(this.state.equals("closed")){
			return this.state.equalsIgnoreCase("Closed");
		}
		else return false;
	}
	
	void addTransaction(double amount) {
		this.TransactionList.add(amount);
	}
	
	String getTransactions() {
		System.out.println("Account #" + this.accountNumber + " transactions:\n");
		for (int i = 0; i < this.TransactionList.size(); i++){
			System.out.println((i+1) + ":" + this.TransactionList.get(i));
		}
		System.out.println("End of transactions\n");
		return "";
	}
	
	int retrieveNumberOfTransactions() {
		return this.TransactionList.size();

	}
	
	String getStatus(int ID){
		if (isOpen(this.state)){
			return "open";
		}
		else if (isSuspended(this.state)){
			return "suspended"; 
		}
		else	return "closed";
	}
	
}
