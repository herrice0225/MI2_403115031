package bank;

import java.util.ArrayList;

public class Bank {
	
	ArrayList<BankAccount> account;
	Bank(){
		this.account = new ArrayList<BankAccount>();
	}
	
/*	void addAccount(int accountNumber, double initialBalance){
		this.account.add(new BankAccount(accountNumber, initialBalance));
		//To build a BankAccount(object)  
	} */ //Remove this method.
	int getAccount(int accountNumber){	
		for(int i = 0; i < account.size(); i++){
			if(account.get(i).accountNumber == accountNumber){	//To get the accountNumbet from account(ArrayList) of BankAccount[i](class)
 				return i;
			}
		}
		return -1;
	}
	
	void deposit(int accountNumber, double initialBalance){
		int i = getAccount(accountNumber);
		if (i >= 0){
			account.get(i).deposit(initialBalance);
		}
	}
	void withdraw(int accountNumber, double initialBalance){
		int i = getAccount(accountNumber);
		if (i >= 0){
			account.get(i).withdraw(initialBalance);
		}
	}
	
	
	double getBalance(int accountNumber){
		int i = getAccount(accountNumber);
		if(i >= 0){
			return account.get(i).getbalance(accountNumber);
		}
		else return -1;
	}
	void suspendAccount(int accountNumber){
		int i = getAccount(accountNumber);
		if(i >= 0){
			account.get(i).suspend();
		}
	}
	void reOpenAccount(int accountNumber){
		int i = getAccount(accountNumber);
		if(i >= 0){
			account.get(i).reOpen();
		}
	}
	void closeAccount(int accountNumber){
		int i = getAccount(accountNumber);
		if(accountNumber >= 0){
			account.get(i).close();
		}
	}
	String getAccountStatus(int accountNumber){
		int i = getAccount(accountNumber);
		return account.get(i).getStatus(accountNumber);
	}
	String summarizeAccountTransactions(int accountNumber){
		int i = getAccount(accountNumber);
		if(i >= 0){
			return account.get(i).getTransactions();
		}
		return "";
	}
	
	String summarizeAllAccounts(){
		System.out.println("Bank Account Summary");
		System.out.println("");
		System.out.println("Account\t\tBalance\t\t#Transactions\t\tStatus");
		for(int i = 0; i < account.size(); i++){
			int accountNum = account.get(i).accountNumber;
			System.out.println(accountNum + "\t\t" + account.get(i).getbalance(accountNum) + "\t\t" + account.get(i).retrieveNumberOfTransactions() + "\t\t\t" + account.get(i).getStatus(accountNum));	
		}
		System.out.println("End of Account Summary");
		return "";
	}
	
	//New methods in assignment 5
	void addCheckingAccount(int accountNumber, double initialBalance){
		this.account.add(new BankAccount(accountNumber, initialBalance,"checking"));
	}	
	void addSavingsAccount(int accountNumber, double initialBalance, double interestRate){
		this.account.add(new BankAccount(accountNumber, initialBalance,"savings"));
	}
	void addInterest(int accountNumber){
		int i = getAccount(accountNumber);		
		double balance2 = this.account.get(i).getbalance(accountNumber);
		BankAccount Savings = new SavingsAccount(accountNumber, balance2, 10);
		SavingsAccount SV;
		if( i >= 0 ){
			SV = (SavingsAccount) Savings;
			SV.addInterest(balance2);
			}
	}
	void deductFees(int accountNumber){
		int i = getAccount(accountNumber);		
		BankAccount Checking = new CheckingAccount(accountNumber, this.account.get(i).getbalance(accountNumber));
		CheckingAccount CC;
		if( i >= 0 ){
			CC = (CheckingAccount) Checking;
			CC.deductFees(this.account.get(i).withdrawNum);
			}
	}
	void transfer(int withdrawAcctNum, int depositAcctNum, double amount){
		int withdrawNum = getAccount(withdrawAcctNum);
		int depositNum = getAccount(depositAcctNum);
		
		if (withdrawNum >= 0 && depositAcctNum >= 0){
			this.account.get(withdrawNum).withdraw(amount);
			this.account.get(depositNum).deposit(amount);
		}
	}
	boolean areEqualAccounts(int accountNumber1, int accountNumber2){
		double d = account.get(accountNumber2).getbalance(accountNumber2);
		
		if(account.get(accountNumber1).equals(d)){
			return true;
		}
		else return false;
	}
/*	String summarizeAllAccounts2(){
		System.out.println("");
		return"";
	} */

}
